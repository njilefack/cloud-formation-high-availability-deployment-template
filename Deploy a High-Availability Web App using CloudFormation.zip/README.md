# cloud-formation-high-availability-deployment-template

url: http://HA-st-LoadB-1DSJET8JEXO0U-135444079.us-west-2.elb.amazonaws.com